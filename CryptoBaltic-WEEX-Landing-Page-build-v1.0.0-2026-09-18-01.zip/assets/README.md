# Campaign Assets

Keep campaign media grouped by purpose:

- `fonts/` contains local font files and font stylesheets.
- `icons/` contains reusable SVG or small interface icons.
- `images/` contains campaign artwork, photos, and raster illustrations.

Reference assets from HTML with paths such as `assets/images/hero.webp`. GitHub Pages copies this directory to the published `assets/` folder.

Brand assets currently include the exact supplied files converted to WebP: `images/weex-logo.webp` from `Logo.png`, `images/cryptobaltic-mark.webp` from `Ellipse 44512798.png`, and `images/language-globe.webp` from `Frame (1).png`. The local Geist variable font is stored in `fonts/` and loaded by the page. The CryptoBaltic wordmark is rendered as HTML so its Geist typography and gradient remain responsive.
